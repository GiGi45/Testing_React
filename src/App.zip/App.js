const Footer = () => {
  return <footer className="card mt-4">
    <div className="card-body">
      Universidad de Lima 2022-0
    </div>
  </footer>
}

function MiBoton() {
  function HandleClick() {
    alert("U supress me :c");
  }
  return <button onClick={HandleClick}>Mi Boton</button>
}

//Mostrar las frutas de color rojo, el resto Verde
const productos = [
  { nombre: "Lechuga", esFruta: false, id: 1 },
  { nombre: "Pepino", esFruta: false, id: 2 },
  { nombre: "Platano", esFruta: true, id: 3 },
  { nombre: "Manzana", esFruta: true, id: 4 }
];

function ListaProductos(props) {
  const lista = props.productos.map(producto =>
    <li style={{ color: producto.esFruta ? 'red' : 'green' }}>
      {producto.nombre}
    </li>);
  return <ul>{lista}</ul>
}

export default function MyApp() {
  return <div>
    <h1>Bienvenido to this webpage</h1>
    <MiBoton />
    <Footer />
    <ListaProductos productos={productos} />
  </div>
}